package java.de.lwv.MetadatenTool.model.vo;

import org.junit.Test;


class Edok_vorlageTest {

    @Test
    void getID() {
    }

    @Test
    void setID() {
    }

    @Test
    void getBEZEICHNUNG() {
    }

    @Test
    void setBEZEICHNUNG() {
    }

    @Test
    void getVERSION() {
    }

    @Test
    void setVERSION() {
    }

    @Test
    void getURL() {
    }

    @Test
    void setURL() {
    }

    @Test
    void getVORLAGE_ART_CODE() {
    }

    @Test
    void setVORLAGE_ART_CODE() {
    }

    @Test
    void getPHASE_CODE() {
    }

    @Test
    void setPHASE_CODE() {
    }

    @Test
    void getGELOESCHT() {
    }

    @Test
    void setGELOESCHT() {
    }

    @Test
    void getANLAGE_DATUM_VORLAGE() {
    }

    @Test
    void setANLAGE_DATUM_VORLAGE() {
    }

    @Test
    void getANLAGE_USER_NR_VORLAGE() {
    }

    @Test
    void setANLAGE_USER_NR_VORLAGE() {
    }

    @Test
    void getANLAGE_ORGNR_VORLAGE() {
    }

    @Test
    void setANLAGE_ORGNR_VORLAGE() {
    }

    @Test
    void getTECHNISCHE_BEZEICHNUNG() {
    }

    @Test
    void setTECHNISCHE_BEZEICHNUNG() {
    }
}