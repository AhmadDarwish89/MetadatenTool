package java.de.lwv.MetadatenTool.model.dao;


import org.junit.Test;

class DaoTest {

    @Test
    void getConnection() {
    }

    @Test
    void closeConnection() {
    }
}