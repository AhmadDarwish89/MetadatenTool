package java.de.lwv.MetadatenTool.view;


import org.junit.Test;

class StartseiteTest {

    @Test
    void main() {
    }
}