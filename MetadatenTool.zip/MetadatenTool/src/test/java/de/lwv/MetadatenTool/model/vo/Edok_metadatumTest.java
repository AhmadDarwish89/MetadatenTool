package java.de.lwv.MetadatenTool.model.vo;


import org.junit.Test;

class Edok_metadatumTest {

    @Test
    void getIDMETA() {
    }

    @Test
    void setIDMETA() {
    }

    @Test
    void getEDOK_VORLAGE_ID() {
    }

    @Test
    void setEDOK_VORLAGE_ID() {
    }

    @Test
    void getMETA_CODE() {
    }

    @Test
    void setMETA_CODE() {
    }

    @Test
    void getVALUE() {
    }

    @Test
    void setVALUE() {
    }

    @Test
    void getANLAGE_DATUM_META() {
    }

    @Test
    void setANLAGE_DATUM_META() {
    }

    @Test
    void getANLAGE_USER_NR_Meta() {
    }

    @Test
    void setANLAGE_USER_NR_Meta() {
    }

    @Test
    void getANLAGE_ORGNR_META() {
    }

    @Test
    void setANLAGE_ORGNR_META() {
    }
}