package java.de.lwv.MetadatenTool.controller;


import org.junit.Test;

class ToolControllerTest {

    @Test
    void getTextAraetxt() {
    }

    @Test
    void berechnunen_Min() {
    }

    @Test
    void berechnunen_Max() {
    }

    @Test
    void getFileExtenion() {
    }

    @Test
    void write_vorlage_Query() {
    }

    @Test
    void write_meta_Query() {
    }

    @Test
    void write_baum_Query() {
    }

    @Test
    void write_konfig_Query() {
    }

    @Test
    void write_Comitted() {
    }

    @Test
    void openFile() {
    }

    @Test
    void löschen_meta() {
    }

    @Test
    void löschen_konfig() {
    }

    @Test
    void löschen_baum() {
    }

    @Test
    void löschen_comitted() {
    }

    @Test
    void getFormattedDate() {
    }

    @Test
    void getFormattedTime() {
    }

    @Test
    void resetCounters() {
    }

    @Test
    void loadValuesFromIni() {
    }
}