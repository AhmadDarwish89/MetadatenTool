package java.de.lwv.MetadatenTool.view;

import org.junit.Test;

class HauptseiteTest {

    @Test
    void displayKonfiguration() {
    }

    @Test
    void deaktivePnlVorlage() {
    }

    @Test
    void main() {
    }
}