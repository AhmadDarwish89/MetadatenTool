package java.de.lwv.MetadatenTool.model.vo;

import org.junit.Test;


class Edok_vorlage_folgeschreiben_konfigurationTest {



    @Test
    void getID_KONFIG() {
    }

    @Test
    void setID_KONFIG() {
    }

    @Test
    void getEDOK_VORLAGE_HAUPTSCHREIBEN_ID() {
    }

    @Test
    void setEDOK_VORLAGE_HAUPTSCHREIBEN_ID() {
    }

    @Test
    void getEDOK_VORLAGE_FOLGESCHREIBEN_ID() {
    }

    @Test
    void setEDOK_VORLAGE_FOLGESCHREIBEN_ID() {
    }

    @Test
    void getOPTIONAL() {
    }

    @Test
    void setOPTIONAL() {
    }

    @Test
    void getVORBELEGT() {
    }

    @Test
    void setVORBELEGT() {
    }

    @Test
    void getREIHENFOLGE_NR() {
    }

    @Test
    void setREIHENFOLGE_NR() {
    }

    @Test
    void getDATEN_UEBERGEBEN() {
    }

    @Test
    void setDATEN_UEBERGEBEN() {
    }
}