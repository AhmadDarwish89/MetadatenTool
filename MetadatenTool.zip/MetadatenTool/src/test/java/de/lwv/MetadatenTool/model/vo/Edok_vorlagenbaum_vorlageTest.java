package java.de.lwv.MetadatenTool.model.vo;

import org.junit.Test;

class Edok_vorlagenbaum_vorlageTest {

    @Test
    void getID_BAUM() {
    }

    @Test
    void setID_BAUM() {
    }

    @Test
    void getEDOK_VORLAGENBAUM_ID() {
    }

    @Test
    void setEDOK_VORLAGENBAUM_ID() {
    }

    @Test
    void getEDOK_VORLAGE_ID_BAUM() {
    }

    @Test
    void setEDOK_VORLAGE_ID_BAUM() {
    }

    @Test
    void getANLAGE_DATUM_BAUM() {
    }

    @Test
    void setANLAGE_DATUM_BAUM() {
    }

    @Test
    void getANLAGE_USER_NR_BAUM() {
    }

    @Test
    void setANLAGE_USER_NR_BAUM() {
    }

    @Test
    void getANLAGE_ORGNR_BAUM() {
    }

    @Test
    void setANLAGE_ORGNR_BAUM() {
    }

    @Test
    void getORDNER() {
    }

    @Test
    void setORDNER() {
    }
}