package main.java.de.lwv.MetadatenTool.model.vo;

public class Edok_vorlagenbaum_vorlage {
    private int ID_BAUM;
    private String EDOK_VORLAGENBAUM_ID;
    private String EDOK_VORLAGE_ID_BAUM;
    private String ANLAGE_DATUM_BAUM;
    private String ANLAGE_USER_NR_BAUM;
    private String ANLAGE_ORGNR_BAUM;
    private String ORDNER;

    public int getID_BAUM() {
        return ID_BAUM;
    }

    public void setID_BAUM(int ID_BAUM) {
        this.ID_BAUM = ID_BAUM;
    }

    public String getEDOK_VORLAGENBAUM_ID() {
        return EDOK_VORLAGENBAUM_ID;
    }

    public void setEDOK_VORLAGENBAUM_ID(String EDOK_VORLAGENBAUM_ID) {
        this.EDOK_VORLAGENBAUM_ID = EDOK_VORLAGENBAUM_ID;
    }

    public String getEDOK_VORLAGE_ID_BAUM() {
        return EDOK_VORLAGE_ID_BAUM;
    }

    public void setEDOK_VORLAGE_ID_BAUM(String EDOK_VORLAGE_ID_BAUM) {
        this.EDOK_VORLAGE_ID_BAUM = EDOK_VORLAGE_ID_BAUM;
    }

    public String getANLAGE_DATUM_BAUM() {
        return ANLAGE_DATUM_BAUM;
    }

    public void setANLAGE_DATUM_BAUM(String ANLAGE_DATUM_BAUM) {
        this.ANLAGE_DATUM_BAUM = ANLAGE_DATUM_BAUM;
    }

    public String getANLAGE_USER_NR_BAUM() {
        return ANLAGE_USER_NR_BAUM;
    }

    public void setANLAGE_USER_NR_BAUM(String ANLAGE_USER_NR_BAUM) {
        this.ANLAGE_USER_NR_BAUM = ANLAGE_USER_NR_BAUM;
    }

    public String getANLAGE_ORGNR_BAUM() {
        return ANLAGE_ORGNR_BAUM;
    }

    public void setANLAGE_ORGNR_BAUM(String ANLAGE_ORGNR_BAUM) {
        this.ANLAGE_ORGNR_BAUM = ANLAGE_ORGNR_BAUM;
    }

    public String getORDNER() {
        return ORDNER;
    }

    public void setORDNER(String ORDNER) {
        this.ORDNER = ORDNER;
    }
}
